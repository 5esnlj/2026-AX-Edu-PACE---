"""Single replaceable boundary for Upstage Solar or another OpenAI-compatible LLM."""
from typing import Any
from app.core.config import get_llm_settings
from app.schemas.common import RewrittenContent


class SolarClient:
    def __init__(self, sdk_client: Any | None = None) -> None:
        settings = get_llm_settings() if sdk_client is None else None
        if sdk_client is not None:
            self._client = sdk_client
        else:
            # SDK is only needed for real API calls; local schema tests work without it.
            from openai import OpenAI
            self._client = OpenAI(
                api_key=settings['api_key'],
                base_url=settings['base_url'],
                timeout=settings['timeout'],
                max_retries=1,
            )
        self.model = settings['model'] if settings is not None else 'test-model'

    def smoke_test(self) -> str:
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[{'role': 'user', 'content': '한국어로 짧게 "Solar 연결 성공"이라고 답해주세요.'}],
            stream=False,
            max_tokens=80,
        )
        return response.choices[0].message.content or ''

    def generate_rewrite(self, *, source_text: str, subject: str, unit: str,
                         grade: int, reading_level: int, target_language: str) -> RewrittenContent:
        # Pydantic schema is strict (all properties required; extra properties forbidden).
        json_schema = RewrittenContent.model_json_schema()
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[
                {'role': 'system', 'content': (
                    '당신은 한국어 학습 지원을 위한 교과 수업 자료 재구성 보조 시스템입니다. '
                    '반드시 원문의 교과 핵심 개념과 논리 관계를 유지하세요. '
                    '원문에 없는 역사적·과학적 사실을 새로 만들지 마세요. '
                    '쉬운 한국어와 핵심어 번역을 제공하되, 번역이 불확실하면 revision_notes에 검토 필요를 명시하세요. '
                    '학생 개인정보를 추론하거나 평가하지 마세요. JSON 스키마를 준수하세요.'
                )},
                {'role': 'user', 'content': (
                    f'과목: {subject}\n단원: {unit}\n학년: {grade}\n'
                    f'학생 읽기 수준(1~4): {reading_level}\n'
                    f'핵심어 번역 언어 코드: {target_language}\n'
                    f'원문:\n{source_text}'
                )},
            ],
            max_tokens=1400,
            stream=False,
            response_format={
                'type': 'json_schema',
                'json_schema': {
                    'name': 'rewritten_content',
                    'strict': True,
                    'schema': json_schema,
                },
            },
        )
        content = response.choices[0].message.content
        if not content:
            raise ValueError('LLM에서 구조화된 텍스트 응답을 받지 못했습니다.')
        return RewrittenContent.model_validate_json(content)

"""Plain-text PDF reader; scanned/image-only PDFs need OCR in a later phase."""
from dataclasses import dataclass
import pymupdf


@dataclass(frozen=True)
class ExtractedPage:
    page_number: int
    text: str


def extract_pdf_pages(data: bytes) -> list[ExtractedPage]:
    if not data.startswith(b'%PDF-'):
        raise ValueError('PDF 파일이 아닙니다.')
    pages: list[ExtractedPage] = []
    with pymupdf.open(stream=data, filetype='pdf') as doc:
        if doc.page_count > 40:
            raise ValueError('MVP에서는 40페이지 이하의 PDF만 지원합니다.')
        for i, page in enumerate(doc, start=1):
            pages.append(ExtractedPage(page_number=i, text=page.get_text('text', sort=True).strip()))
    return pages

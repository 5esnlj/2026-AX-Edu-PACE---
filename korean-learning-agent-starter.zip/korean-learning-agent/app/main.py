from fastapi import FastAPI
from app.api.routes import health, llm, materials

app = FastAPI(
    title='한국어 학습 지원 AI Agent MVP',
    version='0.1.0',
    description='Level 1 JSON contracts, Upstage Solar connection, PDF text extraction',
)
app.include_router(health.router)
app.include_router(llm.router)
app.include_router(materials.router)

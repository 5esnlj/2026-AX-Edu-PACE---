import logging
from fastapi import APIRouter, HTTPException
from app.services.solar_client import SolarClient

router = APIRouter(prefix='/api/v1/llm', tags=['LLM'])
logger = logging.getLogger(__name__)


@router.post('/smoke')
def smoke() -> dict[str, str]:
    try:
        return {'model_reply': SolarClient().smoke_test()}
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.warning('LLM API request failed: %s', type(exc).__name__)
        raise HTTPException(status_code=502, detail='LLM 연결에 실패했습니다. 키, URL, 모델명 및 할당량을 확인하세요.') from exc

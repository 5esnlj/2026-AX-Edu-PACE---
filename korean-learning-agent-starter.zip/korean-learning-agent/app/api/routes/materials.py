import logging
from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import ValidationError
from app.schemas.common import AdaptRequest, AdaptResponse
from app.services.pdf_reader import extract_pdf_pages
from app.agents.material_rewriter import MaterialRewriteAgent
from app.services.solar_client import SolarClient

router = APIRouter(prefix='/api/v1/materials', tags=['Materials'])
logger = logging.getLogger(__name__)


@router.post('/extract')
async def extract_pdf(file: UploadFile = File(...)) -> dict:
    content = await file.read(10 * 1024 * 1024 + 1)
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail='PDF 크기는 10MB 이하여야 합니다.')
    try:
        pages = extract_pdf_pages(content)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.warning('PDF parsing failed: %s', type(exc).__name__)
        raise HTTPException(status_code=400, detail='PDF를 분석하지 못했습니다.') from exc
    return {
        'filename': file.filename,
        'pages': [{'page_number': p.page_number, 'text': p.text} for p in pages],
        'ocr_required': all(not p.text for p in pages),
    }


@router.post('/adapt', response_model=AdaptResponse)
def adapt(request: AdaptRequest) -> AdaptResponse:
    try:
        return MaterialRewriteAgent(SolarClient()).run(request)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except (Exception,) as exc:
        logger.warning('Rewrite failed: %s', type(exc).__name__)
        raise HTTPException(status_code=502, detail='자료 재구성에 실패했습니다. 모델 연결 또는 응답 JSON을 확인하세요.') from exc

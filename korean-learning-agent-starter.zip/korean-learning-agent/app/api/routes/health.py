from fastapi import APIRouter

router = APIRouter()


@router.get('/health')
def health() -> dict[str, str]:
    return {'status': 'ok', 'message': 'API 서버 실행 중 (LLM 연결 여부는 별도 테스트 필요)'}

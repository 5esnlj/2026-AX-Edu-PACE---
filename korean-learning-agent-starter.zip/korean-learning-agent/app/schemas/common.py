"""Canonical, versioned JSON data contracts shared by agents and API."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

SCHEMA_VERSION = '1.0'


class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')


class KoreanLevels(StrictModel):
    # First MVP uses the hackathon's 1-4 scale. Align with the real test before deployment.
    listening: int = Field(ge=1, le=4)
    speaking: int = Field(ge=1, le=4)
    reading: int = Field(ge=1, le=4)
    writing: int = Field(ge=1, le=4)


class StudentProfile(StrictModel):
    student_id: str = Field(min_length=1)
    grade: int = Field(ge=1, le=12)
    primary_language: str = Field(min_length=2, description='BCP-47 code, e.g. vi, uz, mn, bn')
    korean_levels: KoreanLevels


class Material(StrictModel):
    material_id: str = Field(min_length=1)
    subject: str = Field(min_length=1)
    unit: str = Field(min_length=1)
    source_text: str = Field(min_length=1, max_length=12000)


class TermTranslation(StrictModel):
    term_ko: str
    translation: str
    language: str
    easy_definition_ko: str


class RewrittenContent(StrictModel):
    """LLM-generated part; is validated against strict JSON Schema."""
    simplified_text: str
    key_terms: list[TermTranslation]
    revision_notes: list[str]


class AdaptRequest(StrictModel):
    schema_version: Literal['1.0']
    request_id: str = Field(min_length=1)
    student: StudentProfile
    material: Material


class AdaptResponse(StrictModel):
    schema_version: Literal['1.0']
    request_id: str
    student_id: str
    material_id: str
    status: Literal['needs_teacher_review']
    result: RewrittenContent
    review_flags: list[str]

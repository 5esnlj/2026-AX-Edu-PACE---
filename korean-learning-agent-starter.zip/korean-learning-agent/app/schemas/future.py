"""Reserved contracts for the later hackathon levels; no endpoints implemented yet."""
from typing import Literal
from pydantic import Field
from .common import StrictModel, StudentProfile, Material


class BilingualTermEntry(StrictModel):
    term_id: str
    subject: str
    unit: str
    term_ko: str
    language: str
    preferred_translation: str
    source: str


class TranslationCheckRequest(StrictModel):
    request_id: str
    source: Material
    target_language: str
    translated_text: str
    glossary: list[BilingualTermEntry]


class TranslationIssue(StrictModel):
    source_term: str
    observed_translation: str
    suggested_translation: str
    reason: str
    evidence: str
    review_required: bool


class QuizGenerationRequest(StrictModel):
    request_id: str
    student: StudentProfile
    source: Material
    fairness_rules_version: str


class QuizItem(StrictModel):
    item_id: str
    prompt: str
    options: list[str]
    correct_option_index: int = Field(ge=0)
    explanation: str
    source_evidence: str
    teacher_review_required: bool


class LearningEvidence(StrictModel):
    student_id: str
    material_id: str
    item_id: str
    correct: bool
    language_support_used: Literal['none', 'simplified_korean', 'translation', 'visual']


class LearningPathRequest(StrictModel):
    request_id: str
    student: StudentProfile
    evidence: list[LearningEvidence]

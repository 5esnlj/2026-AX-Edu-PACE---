"""Level 1 agent. Keep workflow rules here, separate from HTTP and database."""
from app.schemas.common import AdaptRequest, AdaptResponse, SCHEMA_VERSION
from app.services.solar_client import SolarClient


class MaterialRewriteAgent:
    def __init__(self, llm: SolarClient) -> None:
        self.llm = llm

    def run(self, request: AdaptRequest) -> AdaptResponse:
        result = self.llm.generate_rewrite(
            source_text=request.material.source_text,
            subject=request.material.subject,
            unit=request.material.unit,
            grade=request.student.grade,
            reading_level=request.student.korean_levels.reading,
            target_language=request.student.primary_language,
        )
        return AdaptResponse(
            schema_version=SCHEMA_VERSION,
            request_id=request.request_id,
            student_id=request.student.student_id,
            material_id=request.material.material_id,
            status='needs_teacher_review',
            result=result,
            review_flags=[
                '원문 의미와 교과 개념이 보존되었는지 교사가 검토해야 합니다.',
                '핵심어의 번역과 학생 수준 적합성을 교사가 검토해야 합니다.',
            ],
        )

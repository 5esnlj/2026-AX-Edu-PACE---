"""Environment-based configuration. Never hardcode API credentials in source."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).resolve().parents[2] / '.env')


def get_llm_settings() -> dict[str, str | float]:
    key = os.getenv('LLM_API_KEY', '').strip()
    if not key or key == 'PASTE_YOUR_API_KEY_HERE':
        raise RuntimeError('LLM_API_KEY가 설정되지 않았습니다. 프로젝트 루트의 .env를 확인하세요.')
    return {
        'api_key': key,
        'base_url': os.getenv('LLM_BASE_URL', 'https://api.upstage.ai/v1').strip(),
        'model': os.getenv('LLM_MODEL', 'solar-pro4').strip(),
        'timeout': float(os.getenv('LLM_TIMEOUT_SECONDS', '60')),
    }

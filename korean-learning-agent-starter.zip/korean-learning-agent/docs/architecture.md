# Architecture (MVP v0.1)

## Responsibility boundaries

- `app/api`: HTTP, JSON validation, error handling only. Avoid LLM prompts here.
- `app/schemas`: shared versioned data contracts (`1.0`).
- `app/services/solar_client.py`: the only place that knows the LLM SDK or provider URL.
- `app/agents`: task-specific decisions and prompts. **Only material_rewriter exists in v0.1**.
- `app/workflows`: later chains for vocabulary -> rewrite -> translate -> evaluate.
- `app/services/pdf_reader.py`: deterministic PDF text extraction, no LLM.
- `tests`: schema, HTTP and fake-model tests that need no API key.

## Planned incremental expansion

1. `vocabulary_analyzer.py`: classify subject-specific vocabulary, ideally backed by approved dictionaries.
2. `translation_validator.py`: align source terms with a curated bilingual glossary and flag discrepancies for review.
3. `fairness_evaluator.py` + `quiz_generator.py`: separate generation and evaluation with source-grounded criteria.
4. `report_generator.py`: use diagnostic + item-level evidence to describe uncertainty; do not diagnose concept difficulty from language proficiency alone.
5. `workflows/material_pipeline.py`: orchestrate calls and store intermediate results.
6. `db/`: persistent user, material, glossary, and answer data. Use synthetic data until consent/access design is finished.
7. `frontend/`: teacher review -> publish; student read -> quiz -> feedback.

## Important constraints

- Use a pseudonymous `student_id` and avoid sending name/contact details to the LLM.
- A valid JSON output is NOT a guarantee that a rewrite or translation is correct.
- The initial 1-4 scale is a placeholder; the original proposal also mentions a 6-level scale.
- `ocr_required=true` means text extraction found no text; OCR is **not** implemented.
- The first MVP supports text-first adaptation, not original-PDF layout preservation, visual image generation or automatic PDF creation.
- Never ask the LLM to produce authoritative 'language vs concept' diagnoses from insufficient evidence.

"""Run from project root: python scripts/test_solar.py (requires .env API key)."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.services.solar_client import SolarClient


def main() -> None:
    print('[Solar API 연결 테스트]')
    print(SolarClient().smoke_test())
    print('성공: API에서 텍스트 응답을 받았습니다.')


if __name__ == '__main__':
    main()

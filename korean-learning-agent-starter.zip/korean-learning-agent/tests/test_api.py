from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    r = client.get('/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'


def test_openapi_has_material_endpoints():
    r = client.get('/openapi.json')
    assert '/api/v1/materials/adapt' in r.json()['paths']
    assert '/api/v1/materials/extract' in r.json()['paths']

import json
from pathlib import Path
import pytest
from pydantic import ValidationError
from app.schemas.common import AdaptRequest, AdaptResponse

ROOT = Path(__file__).resolve().parents[1]


def test_sample_request_is_valid():
    request = AdaptRequest.model_validate_json((ROOT / 'samples/adapt_request.json').read_text(encoding='utf-8'))
    assert request.student.korean_levels.reading == 2
    assert request.student.primary_language == 'vi'


def test_reject_out_of_range_level():
    raw = json.loads((ROOT / 'samples/adapt_request.json').read_text(encoding='utf-8'))
    raw['student']['korean_levels']['reading'] = 6
    with pytest.raises(ValidationError):
        AdaptRequest.model_validate(raw)


def test_response_schema_requires_teacher_review():
    schema = AdaptResponse.model_json_schema()
    assert 'status' in schema['properties']

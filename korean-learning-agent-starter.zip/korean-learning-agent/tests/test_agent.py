from pathlib import Path
from app.agents.material_rewriter import MaterialRewriteAgent
from app.schemas.common import AdaptRequest, RewrittenContent, TermTranslation


class FakeLLM:
    def generate_rewrite(self, **kwargs):
        assert kwargs['reading_level'] == 2
        assert kwargs['target_language'] == 'vi'
        return RewrittenContent(
            simplified_text='국민이 정치에 참여하는 제도입니다.',
            key_terms=[TermTranslation(
                term_ko='민주주의', translation='dân chủ',
                language='vi', easy_definition_ko='국민이 정치에 참여하는 제도',
            )],
            revision_notes=['테스트용 가짜 응답'],
        )


def test_agent_with_fake_llm():
    root = Path(__file__).resolve().parents[1]
    req = AdaptRequest.model_validate_json((root / 'samples/adapt_request.json').read_text(encoding='utf-8'))
    result = MaterialRewriteAgent(FakeLLM()).run(req)
    assert result.status == 'needs_teacher_review'
    assert result.result.key_terms[0].term_ko == '민주주의'

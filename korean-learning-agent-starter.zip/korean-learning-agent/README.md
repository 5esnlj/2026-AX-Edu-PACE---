# 한국어 학습 지원 AI Agent — IntelliJ 준비 프로젝트

본 프로젝트는 **실행 가능한 v0.1 백엔드 골격**입니다. 현재 구현: 공통 JSON 규격, Solar API 연결 테스트, PDF 텍스트 추출, Level 1의 최소 쉬운 한국어 재구성 Agent, API 테스트. Level 2~3 및 프론트엔드는 향후 구현 대상입니다.

## 1. IntelliJ에서 열기 (Windows PowerShell)

1. IntelliJ IDEA의 Settings > Plugins에서 **Python** 플러그인을 설치·활성화합니다.
2. 이 폴더를 압축 해제하고 File > Open에서 `korean-learning-agent` 폴더를 선택합니다.
3. Python 3.11 이상을 설치합니다. (3.11 또는 3.12 권장)
4. IntelliJ 터미널에서 아래 실행:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

5. `.env` 파일의 `LLM_API_KEY`를 **자신의 키**로 변경합니다. (개인 키는 채팅/깃허브에 공유하지 마세요.)
6. IntelliJ의 Python Interpreter / Python SDK를 `.venv\Scripts\python.exe`로 설정합니다.

## 2. 작동 확인

API 키 없이 가능한 로컬 테스트:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

브라우저에서 `http://127.0.0.1:8000/docs`로 접속해 자동 생성된 API 테스트 화면을 확인합니다. `GET /health`는 Solar와 무관하게 성공합니다.

API 키 설정 뒤 최초 Solar 연결 확인:

```powershell
.\.venv\Scripts\python.exe scripts\test_solar.py
```

또는 `/docs`의 `POST /api/v1/llm/smoke`를 실행할 수 있습니다. **해당 명령부터 외부 API 호출·사용량이 발생합니다.**

## 3. 첫 재구성 테스트

1. API 서버 실행 후 `http://127.0.0.1:8000/docs`에 접속합니다.
2. `POST /api/v1/materials/adapt` > Try it out을 누릅니다.
3. `samples/adapt_request.json`의 내용을 요청 본문에 붙여넣습니다.
4. Execute를 누르면 JSON 결과가 나옵니다. `status`는 항상 `needs_teacher_review`입니다.
5. PDF가 있다면 `POST /api/v1/materials/extract`로 텍스트를 먼저 추출해볼 수 있습니다.

**실제 Solar 응답은 여기서 검증하지 않았습니다.** 제공받은 API 사용 예제의 키/엔드포인트/모델명이 공식 Upstage와 다를 수 있으므로, 받았던 예제 코드를 확인한 후 `.env` 또는 `solar_client.py`를 조정해야 합니다.

## 4. 주요 폴더

```
app/
  main.py                    # FastAPI 시작점
  core/config.py             # .env 읽기
  api/routes/                # health, llm, materials HTTP endpoints
  schemas/common.py          # Level 1 JSON 입출력 계약
  schemas/future.py          # Level 2~3 예정 계약 (미구현)
  services/solar_client.py   # 모델 호출, 교체 지점
  services/pdf_reader.py     # 텍스트 PDF 추출
  agents/material_rewriter.py# Level 1 최소 Agent
  workflows/                 # 이후 워크플로우 구현
samples/adapt_request.json  # 테스트 요청 JSON
scripts/test_solar.py       # 실제 Solar 연결 테스트
```

## 보안/학습 데이터 주의

학생 이름 및 개인정보 대신 가명 식별자만 사용하고, 최초 개발 중에는 합성 데이터만 입력합니다. `.env`는 gitignore에 들어 있으며 절대 Git에 올리지 마세요. 외부 모델에 업로드할 교과 PDF는 이용 권한을 확인해야 합니다.

## 사전 검증 범위

- 오프라인 단위 테스트 가능
- 서버 기동 및 OpenAPI 스키마 점검 가능
- 실제 Solar 모델 호출은 본인의 API 키가 필요함
- 저자원 언어 번역 품질과 공정성 검증은 미구현
